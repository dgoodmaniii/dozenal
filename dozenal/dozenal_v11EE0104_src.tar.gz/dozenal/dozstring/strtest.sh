#!/bin/bash

echo "64hello78";
./dozstring -n -xA -eB -p'&' -c"64hello78";
echo  "------------------------------";
echo "73hello 54what 1492 stop it who 11 how 45* hello 15yes yes15 what.now";
./dozstring -n -xA -eB -p'&' -c"73hello 54what 1492 stop it who 11 how 45* hello 15yes yes15 what.now";
echo  "------------------------------";
echo "73hello 54what 1492 stop it who 11 how 45* hello 15yes yes15 what.now";
./dozstring -sn -xA -eB -p'&' -c"73hello 54what 1492 stop it who 11 how 45* hello 15yes yes15 what.now";
