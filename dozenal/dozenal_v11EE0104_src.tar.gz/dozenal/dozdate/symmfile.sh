# +AMDG  This document was begun on 26 Aug 11X8, the feast of
# St. Rose of Lima, and it is humbly dedicated to her and to
# the Immaculate Heart of Mary for their prayers, and to the
# Sacred Heart of Jesus for His mercy.

./dozdate -Ssf symmfile.txt > symm_results_2.txt;
diff symm_results_2.txt symmans.txt;
