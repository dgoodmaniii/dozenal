#!/bin/bash

./dozdate -d"27 Dec 11E5" "%B";
./dozdate -sd"27 Dec 11E5" "%B";
./dozdate -Ssd"27 Dec 11E5" "%B";
./dozdate -Yd"27 Dec 11E5" "%B";
