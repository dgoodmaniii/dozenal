#!/bin/bash

./dozdate -d"Wednesday"
./dozdate -d"last Wednesday"
