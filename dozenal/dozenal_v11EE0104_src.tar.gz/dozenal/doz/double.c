/* +AMDG */

#include<stdio.h>
#include<float.h>

int main(void)
{
	printf("%e\n",DBL_MIN);
}
