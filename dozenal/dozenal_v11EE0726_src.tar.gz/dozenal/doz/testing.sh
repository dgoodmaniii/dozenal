#!/bin/bash
# +AMDG

echo "One third:  `./doz 0.3333333333333333333333333`";
echo "One third:  `./doz 0.3333333333333333`";
echo "Two thirds:  `./doz 0.66666666666666666666666`";
echo "Two thirds:  `./doz 0.666666666666666`";
echo "Smallest:  `./doz -ek19 4.9406564584124654e-324`";
