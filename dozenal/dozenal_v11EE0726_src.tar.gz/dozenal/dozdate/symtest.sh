#!/bin/bash
#
#./dozdate -d"10 Apr 1187"
#echo -e "Sat 11 Apr 1187 (projected)\n`./dozdate -sd"10 Apr 1187"`"
#echo ""
#
#./dozdate -d"25 Dec 1191"
#echo -e "Tue 02 Irv 1191 (projected)\n`./dozdate -sd"25 Dec 1191"`"
#echo ""
#
#./dozdate -d"3 Jan 1192"
#echo -e "Sun 07 Irv 1191 (projected)\n`./dozdate -sd"3 Jan 1192"`"
#echo ""
#
#./dozdate -d"4 Jan 1192"
#echo -e "Mon 01 Jan 1192 (projected)\n`./dozdate -sd"4 Jan 1192"`"
#echo ""
#
#./dozdate -d"25 Dec 1191" "%b"
#echo -e "Irv (projected)\n`./dozdate -sd"25 Dec 1191" "%b"`"
#echo ""
#
#./dozdate -d"25 Jan 1190" "%B"
#echo -e "January (projected)\n`./dozdate -sd"25 Jan 1190" "%B"`";
#echo ""
#
#./dozdate -d"25 Dec 1190" "%B"
#echo -e "January (projected)\n`./dozdate -sd"25 Dec 1190" "%B"`";
#echo ""
#
#./dozdate -d"24 Dec 1190" "%B"
#echo -e "December (projected)\n`./dozdate -sd"24 Dec 1190" "%B"`";
#echo ""
#
#./dozdate -d"25 Dec 1191" "%B"
#echo -e "Irvember (projected)\n`./dozdate -sd"25 Dec 1191" "%B"`";
#echo ""
#
#echo -e "Sun 03 Jan 1192 (projected)\n`./dozdate -Sd"7 Irv 1191"`";
#echo "";
#
#echo -e "Fri 05 Apr 11E5 (projected)\n`./dozdate -Sd"7 Apr 11E5"`";
#echo "";
#
#echo -e "Sun 07 Apr 11E5 (projected)\n`./dozdate -sd"5 Apr 11E5"`";
#echo "";
#
#echo -e "Sun 07 Apr 11E5 (projected)\n`./dozdate -Ssd"7 Apr 11E5"`";
#echo -e "Sun 07 Apr 11E5 (projected)\n`./dozdate -sSd"7 Apr 11E5"`";
#echo "";
#
echo -e "1191-11-05 (projected)\n`./dozdate -Ssd"5 Irv 1191" "%Y-%m-%d"`";
echo -e "`./dozdate -Ssd"5 Jan 1191" "%Y-%m-%d"`";
echo -e "`./dozdate -Ssd"5 Feb 1191" "%Y-%m-%d"`";
echo -e "`./dozdate -Ssd"26 Dec 1191" "%Y-%m-%d"`";
echo -e "`./dozdate -sd"25 Dec 1191" "%Y-%m-%d"`";
echo -e "`./dozdate -sd"27 Dec 1191" "%Y-%m-%d"`";
echo -e "`./dozdate -sd"04 Jan 1192" "%Y-%m-%d"`";
echo ""
echo -e "`./dozdate -Ssd"04 Irv 1192"`";
echo -e "`./dozdate -Ssd"04 Irv 1191"`";
echo -e "`./dozdate -Ssd"Sun 04 Irv 1191"`";
